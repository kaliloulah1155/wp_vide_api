jQuery.fn.highlight=function(c){function e(b,c){var d=0;if(3==b.nodeType){var a=b.data.toUpperCase().indexOf(c),a=a-(b.data.substr(0,a).toUpperCase().length-b.data.substr(0,a).length);if(0<=a){d=document.createElement("span");d.className="highlight";a=b.splitText(a);a.splitText(c.length);var f=a.cloneNode(!0);d.appendChild(f);a.parentNode.replaceChild(d,a);d=1}}else if(1==b.nodeType&&b.childNodes&&!/(script|style)/i.test(b.tagName))for(a=0;a<b.childNodes.length;++a)a+=e(b.childNodes[a],c);return d} return this.length&&c&&c.length?this.each(function(){e(this,c.toUpperCase())}):this};jQuery.fn.removeHighlight=function(){return this.find("span.highlight").each(function(){this.parentNode.firstChild.nodeName;with(this.parentNode)replaceChild(this.firstChild,this),normalize()}).end()};

(function($){

    "use strict";

    function productSearch(form,query,currentQuery,timeout,element){

        var search      = form.find('.search'),
            category    = form.find('.category option:selected').attr('data-id'),
            inCat       = form.attr('data-in-category'),
            inTerm      = form.attr('data-in-term'),
            sku         = form.attr('data-sku'),
            description = form.attr('data-description');

        if (inCat.length) {
            category = inCat;
        }

        form.find('.search-results').html('').removeClass('active');

        query = query.trim();

        if (query.length >= 3) {

            if (timeout) {
                clearTimeout(timeout);
            }

            form.find('.search-results').removeClass('empty');

            search.parent().addClass('loading');
            if (query != currentQuery) {
                timeout = setTimeout(function() {

                    $.ajax({
                        url:psearch_opt.ajaxUrl,
                        type: 'post',
                        data: { action: 'search_product', keyword: query, category: category, sku: sku, description: description, term:inTerm },
                        success: function(data) {
                            currentQuery = query;
                            search.parent().removeClass('loading');

                            if (!form.find('.search-results').hasClass('empty')) {

                                if (data.length) {

                                    data = JSON.parse(data);

                                    // if (typeof(data['args']) != 'undefined') {
                                    //     console.log(data['args']);
                                    // }

                                    form.find('.search-results').html('<ul>'+data['output']+'</ul>').addClass('active');
                                    var scroll = element.querySelector('ul');
                                    if (typeof scroll != "undefined" && scroll != null && form.find('.search-results ul li').length > 2) {
                                        SimpleScrollbar.initEl(scroll);
                                    }

                                    form.find('.search-results').highlight(query);

                                } else {
                                    form.find('.search-results').html('<ul><li class="no-results">'+psearch_opt.noResults+'</li></ul>').addClass('active');
                                }

                            }

                            clearTimeout(timeout);
                            timeout = false;


                        }
                    });

                }, 500);
            }
        } else {

            search.parent().removeClass('loading');
            form.find('.search-results').empty().removeClass('active').addClass('empty');

            clearTimeout(timeout);
            timeout = false;

        }
    }

    $('form[name="product-search"]').each(function(){

        var element       = this,
            form          = $(this),
            search        = form.find('.search'),
            category      = form.find('.category'),
            inCat         = form.attr('data-in-category'),
            currentQuery  = '',
            timeout       = false,
            button        = form.find('input[type="submit"]');

        if (inCat != null) {
            form.find('.category option[data-id="'+inCat+'"]').attr('selected','selected').siblings().removeAttr('selected');
        }

        var mouse_is_inside = false;

        category.on('change',function(){
            currentQuery  = '';
            var query = search.val();
            productSearch(form,query,currentQuery,timeout,element);

            mouse_is_inside = true;
        });

        search.keyup(function(e){

            var code = (e.keyCode || e.which);

            if(code == 37 || code == 38 || code == 39 || code == 40) {
                return;
            }
            
            var query = $(this).val();
            productSearch(form,query,currentQuery,timeout,element);

            mouse_is_inside = true;
        });

        button.on('click',function(e){

            e.preventDefault();

            var url        = button.data('shop')+'?post_type=product',
                activeCat  = category.find('option:selected').val(),
                activeTerm = form.attr('data-in-term'),
                searchVal  = search.val(); 

            if (typeof(activeCat) != 'undefined' && activeCat.length) {
                url += '&product_cat='+activeCat;
            }

            if (typeof(activeTerm) != 'undefined' && activeTerm.length) {
                activeTerm = activeTerm.split(',');

                var filter = activeTerm[1];
                    filter = filter.replace('pa_','filter_');

                url += '&'+filter+'='+activeTerm[0];
            }

            if (typeof(searchVal) != 'undefined' && searchVal.length) {
                
                url += '&s='+searchVal;

                url = encodeURI(url);

                window.location.replace(url);
            }

        });

        $("body").on('mouseup',function(){
            if(mouse_is_inside){
                $('.search-results').removeClass('active');
            }
        });

    });

})(jQuery);