(function($){

    "use strict";

    var request         = false;
    var firstRequest    = true;
    var shopURLOriginal = pfilter_opt.shopURL;
    var shopName        = pfilter_opt.shopName+'-compare';
    var defaultSort     = $('.woocommerce-ordering select option:selected').val();
    var noMore          = pfilter_opt.noMore;
    var loadMore        = $("#loadmore .text").text();
    var defaultLayout   = $(".layout-control").data('layout');
    var defaultSize     = $(".layout-control").data('size');

    function unique(array){
        return array.filter(function (value, index, self) {
            return self.indexOf(value) === index;
        });
    }

    jQuery.fn.inView = function(win,observe) {

        var observe  = (observe) ? observe : 0.6,
            win      = (win) ? win : window,
            height   = jQuery(this).outerHeight(),
            scrolled = jQuery(win).scrollTop(),
            viewed   = scrolled + jQuery(win).height(),
            top      = jQuery(this).offset().top,
            bottom   = top + height;
        return (top + height * observe) <= viewed && (bottom - height * observe) >= scrolled;
        
    };

    function isInArray(value, array) {return array.indexOf(value) > -1;}

    function onCompareWishlistAddToCartComplete(){
        $('.et-mobile-tab').addClass('active');
        $('.et-mobile-tab .mob-tabset-toggle:not(.active)').trigger('click');
    }

    function compareCountUpdate(mult){
        var compare_count = parseInt($('.compare-contents').html());
        compare_count += mult;
        if (compare_count < 0) {compare_count = 0;}
        $('.compare-contents').html(compare_count);
        if (compare_count > 0) {
            $('.compare-contents').addClass('count');
        } else {
            $('.compare-contents').removeClass('count');
        }
    }

    function onCompareComplete(target, title){
        setTimeout(function(){
            if (target.find('.single-product-wrapper').length) {
                target.find('.summary').find('.compare-toggle')
                .removeClass('loading')
                .addClass('active')
                .attr('title',title);

                target.find('.summary').find('.compare-title').html(title);
            } else {
                target.find('.compare-toggle')
                .removeClass('loading')
                .addClass('active')
                .attr('title',title);

                target.find('.compare-title').html(title);
            }

            compareCountUpdate(1);

        },800);
    }

    function wishlistCountUpdate(mult){
        var wishlist_count = parseInt($('.wishlist-contents').html());
        wishlist_count += mult;
        if (wishlist_count < 0) {wishlist_count = 0;}
        $('.wishlist-contents').html(wishlist_count);
        if (wishlist_count > 0) {
            $('.wishlist-contents').addClass('count');
        } else {
            $('.wishlist-contents').removeClass('count');
        }
    }

    function onWishlistComplete(target, title){
        setTimeout(function(){
            target.find('.wishlist-toggle')
            .removeClass('loading')
            .addClass('active')
            .attr('title',title);

            target.find('.wishlist-title').html(title);

            wishlistCountUpdate(1);
            onCompareWishlistAddToCartComplete();
        },800);
    }

    function highlightWishlist(wishlist,title){
        var addedWishlist  = wishlist_opt.addedWishlist;
        $('.wishlist-toggle').each(function(){
            var $this = $(this);
            var currentProduct = $this.data('product');
            currentProduct = currentProduct.toString();
            if (isInArray(currentProduct,wishlist)) {
                $this.addClass('active').attr('title',title);
                $this.next('.wishlist-title').html(addedWishlist).attr('title',title);
            }
        });
    }

    function ajaxAddToCart(){
        $('ul > .product').each(function(){

            var $this = $(this);
            var addToCard = $this.find('.ajax_add_to_cart');
            var productProgress = $this.find('.ajax-add-to-cart-loading');
            var addToCardEvent  = true;

            if (addToCard.hasClass('added')) {
                addToCardEvent  = false;
            }

            if (addToCard.attr('data-product_status') == 'outofstock') {
                addToCardEvent  = false;
            }

            if (addToCard.attr('data-product_type') == 'variable') {
                addToCardEvent  = false;
            }

            addToCard.on('click',function(){
                if (addToCardEvent == true) {
                    var $self = $(this);
                    productProgress.addClass('active');
                    setTimeout(function(){
                        productProgress.addClass('load-complete');
                        gsap.to(productProgress.find('.tick'),0.2, {
                          opacity:1,
                        });
                        gsap.to(productProgress.find('.tick'),0.8, {
                          scale:1.15,
                          ease:"elastic.out"
                        });
                        setTimeout(function(){
                            productProgress.removeClass('active').removeClass('load-complete');
                            addToCardEvent  = false;
                        }, 500);

                        onCompareWishlistAddToCartComplete();
                    }, 1500);
                } else {
                    alert(pfilter_opt.already);
                }
            });
        });
    }

    function productCompare(){
        if(typeof(compare_opt) != 'undefined'){
            var compare      = new Array,
                inCompare    = compare_opt.inCompare,
                addedCompare = compare_opt.addedCompare,
                ls           = localStorage.getItem(shopName);

            if (typeof(ls) != 'undefined' && ls != null) {
                if (ls.length) {
                    ls = ls.split(',');
                    ls = unique(ls);
                    compare = ls;
                }
            }

            $('.compare-toggle').each(function(){

                var $this = $(this);

                var currentProduct = $this.data('product');

                currentProduct = currentProduct.toString();

                if (isInArray(currentProduct,compare)) {
                    $this.addClass('active').attr('title',inCompare);
                    $this.next('.compare-title').html(addedCompare).attr('title',inCompare);
                }

                $(this).on('click',function(e){

                    if (!$this.hasClass('active') && !$this.hasClass('loading')) {
                        e.preventDefault();
                        $this.addClass('loading');

                        compare.push(currentProduct);
                        compare = unique(compare);

                        localStorage.setItem(shopName, compare.toString());
                        onCompareComplete($this.parents('.product'), inCompare);

                    }

                });
            });

            $('.comp .compare-title,.entry-summary .compare-title').on('click',function(){
                var $this = $(this);
                if ($this.html() != inCompare) {
                        $this.addClass('loading');
                    $this.prev('.compare-toggle').trigger('click');
                    setTimeout(function(){
                        $this.removeClass('loading');
                        $this.html(inCompare);
                    },600);
                } else {
                    window.location.replace($this.prev('.compare-toggle').attr('href'));
                }
            });
        }
    }

    function productWishlist(){
        if (typeof(wishlist_opt) != 'undefined') {
            var inWishlist = wishlist_opt.inWishlist,
                addedWishlist  = wishlist_opt.addedWishlist,
                wishlist   = new Array,
                ls         = localStorage.getItem(shopName),
                loggedIn   = ($('body').hasClass('logged-in')) ? true : false,
                userData   = '';

            if(loggedIn) {
                // Fetch current user data
                $.ajax({
                    type: 'POST',
                    url: pfilter_opt.ajaxUrl,
                    data: {
                        'action' : 'fetch_user_data',
                        'dataType': 'json'
                    },
                    success:function(data) {

                        userData = JSON.parse(data);
                        if (typeof(userData['wishlist']) != 'undefined' && userData['wishlist'] != null && userData['wishlist'] != "") {

                            var userWishlist = userData['wishlist'];
                            userWishlist = userWishlist.split(',');

                            if (wishlist.length) {
                                wishlist =  wishlist.concat(userWishlist);

                                $.ajax({
                                    type: 'POST',
                                    url:wishlist_opt.ajaxPost,
                                    data:{
                                        action:'user_wishlist_update',
                                        user_id :userData['user_id'],
                                        wishlist :wishlist.join(','),
                                    }
                                });

                            } else {
                                wishlist =  userWishlist;
                            }

                            wishlist = unique(wishlist);

                            highlightWishlist(wishlist,inWishlist);
                            localStorage.removeItem(shopName);

                        } else {
                            if (typeof(ls) != 'undefined' && ls != null) {
                                ls = ls.split(',');
                                ls = unique(ls);
                                wishlist = ls;
                            }

                            $.ajax({
                                type: 'POST',
                                url:wishlist_opt.ajaxPost,
                                data:{
                                    action:'user_wishlist_update',
                                    user_id :userData['user_id'],
                                    wishlist :wishlist.join(','),
                                }
                            })
                            .done(function(response) {
                                highlightWishlist(wishlist,inWishlist);
                                localStorage.removeItem(shopName);
                            });
                        }
                    },
                    error: function(){
                        console.log('No user data returned');
                    }
                });
            } else {
                if (typeof(ls) != 'undefined' && ls != null) {
                    if (ls.length) {
                        ls = ls.split(',');
                        ls = unique(ls);
                        wishlist = ls;
                    }
                }
            }

            $('.wishlist-toggle').each(function(){

                var $this = $(this);

                var currentProduct = $this.data('product');

                currentProduct = currentProduct.toString();

                if (!loggedIn && isInArray(currentProduct,wishlist)) {
                    $this.addClass('active').attr('title',inWishlist);
                    $this.next('.wishlist-title').html(addedWishlist).attr('title',inWishlist);
                }

                $(this).on('click',function(e){
                    
                    if (!$this.hasClass('active') && !$this.hasClass('loading')) {
                        e.preventDefault();
                        $this.addClass('loading');

                        wishlist.push(currentProduct);
                        wishlist = unique(wishlist);

                        if (loggedIn) {
                            // get user ID
                            if (userData['user_id']) {
                                $.ajax({
                                    type: 'POST',
                                    url:wishlist_opt.ajaxPost,
                                    data:{
                                        action:'user_wishlist_update',
                                        user_id :userData['user_id'],
                                        wishlist :wishlist.join(','),
                                    }
                                })
                                .done(function(response) {
                                    onWishlistComplete($this.parents('.product'), inWishlist);
                                })
                                .fail(function(data) {
                                    alert(wishlist_opt.error);
                                });
                            }
                        } else {

                            localStorage.setItem(shopName, wishlist.toString());
                            onWishlistComplete($this.parents('.product'), inWishlist);

                        }

                        // Wishlist count

                        $.ajax({
                            type: 'POST',
                            url:wishlist_opt.ajaxPost,
                            data:{
                                action:'wishlist_count_update',
                                product_id :currentProduct,
                            }
                        })
                        .done(function() {
                            var wishlistCount = $('.single-product .wishlist-count').html();
                            wishlistCount++;
                            $('.single-product .wishlist-count').html(wishlistCount);
                        });

                    }


                });
            });

            $('.comp .wishlist-title,.entry-summary .wishlist-title').on('click',function(){

                var $this = $(this);
                if ($this.html() != inWishlist) {
                    $this.addClass('loading');
                    $this.prev('.wishlist-toggle').trigger('click');
                    setTimeout(function(){
                        $this.removeClass('loading');
                        $this.html(inWishlist);
                    },600);
                } else {
                    window.location.replace($this.prev('.wishlist-toggle').attr('href'));
                }
            });
        }
    }

    function toggle_hidden_variation_btn() {
        const resetVariationNodes = document.getElementsByClassName('reset_variations');

        if (resetVariationNodes.length) {

            Array.prototype.forEach.call(resetVariationNodes, function (resetVariationEle) {

                let observer = new MutationObserver(function () {

                    if (resetVariationEle.style.visibility !== 'hidden') {

                        resetVariationEle.style.display = 'block';

                    } else {

                        resetVariationEle.style.display = 'none';

                    }

                });

                observer.observe(resetVariationEle, {attributes: true, childList: true});

            })

        }
    }

    if (typeof(quickview_opt) != "undefined") {

        var ProductGallery = function( $target, args ) {
            this.$target = $target;
            this.$images = $( '.woocommerce-product-gallery__image', $target );

            // No images? Abort.
            if ( 0 === this.$images.length ) {
                this.$target.css( 'opacity', 1 );
                return;
            }

            // Make this object available.
            $target.data( 'product_gallery', this );

            // Pick functionality to initialize...
            this.flexslider_enabled = 'function' === typeof $.fn.flexslider && quickview_opt.flexslider_enabled;
            this.zoom_enabled       = 'function' === typeof $.fn.zoom && quickview_opt.zoom_enabled;
            this.photoswipe_enabled = typeof PhotoSwipe !== 'undefined' && quickview_opt.photoswipe_enabled;

            // ...also taking args into account.
            if ( args ) {
                this.flexslider_enabled = false === args.flexslider_enabled ? false : this.flexslider_enabled;
                this.zoom_enabled       = false === args.zoom_enabled ? false : this.zoom_enabled;
                this.photoswipe_enabled = false === args.photoswipe_enabled ? false : this.photoswipe_enabled;
            }

            // ...and what is in the gallery.
            if ( 1 === this.$images.length ) {
                this.flexslider_enabled = false;
            }

            // Bind functions to this.
            this.initFlexslider       = this.initFlexslider.bind( this );
            this.initZoom             = this.initZoom.bind( this );
            this.initZoomForTarget    = this.initZoomForTarget.bind( this );
            this.initPhotoswipe       = this.initPhotoswipe.bind( this );
            this.onResetSlidePosition = this.onResetSlidePosition.bind( this );
            this.getGalleryItems      = this.getGalleryItems.bind( this );
            this.openPhotoswipe       = this.openPhotoswipe.bind( this );

            if ( this.flexslider_enabled ) {
                this.initFlexslider( args.flexslider );
                $target.on( 'woocommerce_gallery_reset_slide_position', this.onResetSlidePosition );
            } else {
                this.$target.css( 'opacity', 1 );
            }

            if ( this.zoom_enabled ) {
                this.initZoom();
                $target.on( 'woocommerce_gallery_init_zoom', this.initZoom );
            }

            if ( this.photoswipe_enabled ) {
                this.initPhotoswipe();
            }
        };

        ProductGallery.prototype.initFlexslider = function( args ) {
            var $target = this.$target,
                gallery = this;

            var options = $.extend( {
                selector: '.woocommerce-product-gallery__wrapper > .woocommerce-product-gallery__image',
                start: function() {
                    $target.css( 'opacity', 1 );
                },
                after: function( slider ) {
                    gallery.initZoomForTarget( gallery.$images.eq( slider.currentSlide ) );
                }
            }, args );

            $target.flexslider( options );

            // Trigger resize after main image loads to ensure correct gallery size.
            $( '.woocommerce-product-gallery__wrapper .woocommerce-product-gallery__image:eq(0) .wp-post-image' ).one( 'load', function() {
                var $image = $( this );

                if ( $image ) {
                    setTimeout( function() {
                        var setHeight = $image.closest( '.woocommerce-product-gallery__image' ).height();
                        var $viewport = $image.closest( '.flex-viewport' );

                        if ( setHeight && $viewport ) {
                            $viewport.height( setHeight );
                        }
                    }, 100 );
                }
            } ).each( function() {
                if ( this.complete ) {
                    $( this ).trigger( 'load' );
                }
            } );
        };

    
        ProductGallery.prototype.initZoom = function() {
            this.initZoomForTarget( this.$images.first() );
        };

        ProductGallery.prototype.initZoomForTarget = function( zoomTarget ) {
            if ( ! this.zoom_enabled ) {
                return false;
            }

            var galleryWidth = this.$target.width(),
                zoomEnabled  = false;

            $( zoomTarget ).each( function( index, target ) {
                var image = $( target ).find( 'img' );

                if ( image.data( 'large_image_width' ) > galleryWidth ) {
                    zoomEnabled = true;
                    return false;
                }
            } );

            // But only zoom if the img is larger than its container.
            if ( zoomEnabled ) {
                var zoom_options = $.extend( {
                    touch: false
                }, quickview_opt.zoom_options );

                if ( 'ontouchstart' in document.documentElement ) {
                    zoom_options.on = 'click';
                }

                zoomTarget.trigger( 'zoom.destroy' );
                zoomTarget.zoom( zoom_options );

                setTimeout( function() {
                    if ( zoomTarget.find(':hover').length ) {
                        zoomTarget.trigger( 'mouseover' );
                    }
                }, 100 );
            }
        };

        ProductGallery.prototype.initPhotoswipe = function() {
            if ( this.zoom_enabled && this.$images.length > 0 ) {
                this.$target.prepend( '<a href="#" class="woocommerce-product-gallery__trigger">🔍</a>' );
                this.$target.on( 'click', '.woocommerce-product-gallery__trigger', this.openPhotoswipe );
                this.$target.on( 'click', '.woocommerce-product-gallery__image a', function( e ) {
                    e.preventDefault();
                });

                // If flexslider is disabled, gallery images also need to trigger photoswipe on click.
                if ( ! this.flexslider_enabled ) {
                    this.$target.on( 'click', '.woocommerce-product-gallery__image a', this.openPhotoswipe );
                }
            } else {
                this.$target.on( 'click', '.woocommerce-product-gallery__image a', this.openPhotoswipe );
            }
        };

        ProductGallery.prototype.onResetSlidePosition = function() {
            this.$target.flexslider( 0 );
        };

        ProductGallery.prototype.getGalleryItems = function() {
            var $slides = this.$images,
                items   = [];

            if ( $slides.length > 0 ) {
                $slides.each( function( i, el ) {
                    var img = $( el ).find( 'img' );

                    if ( img.length ) {
                        var large_image_src = img.attr( 'data-large_image' ),
                            large_image_w   = img.attr( 'data-large_image_width' ),
                            large_image_h   = img.attr( 'data-large_image_height' ),
                            alt             = img.attr( 'alt' ),
                            item            = {
                                alt  : alt,
                                src  : large_image_src,
                                w    : large_image_w,
                                h    : large_image_h,
                                title: img.attr( 'data-caption' ) ? img.attr( 'data-caption' ) : img.attr( 'title' )
                            };
                        items.push( item );
                    }
                } );
            }

            return items;
        };

        ProductGallery.prototype.openPhotoswipe = function( e ) {
            e.preventDefault();

            var pswpElement = $( '.pswp' )[0],
                items       = this.getGalleryItems(),
                eventTarget = $( e.target ),
                clicked;

            if ( eventTarget.is( '.woocommerce-product-gallery__trigger' ) || eventTarget.is( '.woocommerce-product-gallery__trigger img' ) ) {
                clicked = this.$target.find( '.flex-active-slide' );
            } else {
                clicked = eventTarget.closest( '.woocommerce-product-gallery__image' );
            }

            var options = $.extend( {
                index: $( clicked ).index(),
                addCaptionHTMLFn: function( item, captionEl ) {
                    if ( ! item.title ) {
                        captionEl.children[0].textContent = '';
                        return false;
                    }
                    captionEl.children[0].textContent = item.title;
                    return true;
                }
            }, quickview_opt.photoswipe_options );

            // Initializes and opens PhotoSwipe.
            var photoswipe = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options );
            photoswipe.init();
        };

        $.fn.wc_product_gallery = function( args ) {
            new ProductGallery( this, args || quickview_opt );
            return this;
        };

    }

    function scrollbar(){

        var widgets = [].slice.call(document.querySelectorAll('.pf-item.list.attr ul, .pf-item.col.attr ul'));

        if (typeof widgets != "undefined" && widgets != null) {
            widgets.forEach(function(widget) {
                if (widget.querySelectorAll('li').length > 6) {
                    widget.classList.add("max");
                    SimpleScrollbar.initEl(widget);
                }
            });
        }
    }

    function catLayout(){

        $('.pf-item.list[data-attribute="ca"]').each(function(){

            var $this = $(this);

            $this.find('li > a > span.toggle').on('click',function(e){
                e.stopImmediatePropagation();
                $(this).toggleClass('active');
                if ($(this).parent().next('ul').length != 0) {
                    $(this).parent().toggleClass('animate');
                    $(this).parent().next('ul').stop().slideToggle(300);
                    $(this).parents('li').siblings().find('ul').stop().slideUp(300);
                };
                e.preventDefault();
            });

        });

        $('.pf-item.image[data-attribute="ca"]').each(function(){

            var $this = $(this);

            $this.find('li > a').on('click',function(){

                var a = $(this);

                a.parent().toggleClass('active');
                a.parent().siblings().removeClass('active');

                if (a.next('ul').length != 0) {
                    a.parent().addClass('isolate');
                    $this.find('.isolate').not(a.parent()).addClass('disable');
                    a.parent().siblings().addClass('hide');
                    a.parents('ul').addClass('grid-off');
                };
            });

            $this.find('.clear-attribute').on('click',function(){
                $this.find('.isolate').removeClass('isolate').removeClass('disable');
                $this.find('.hide').removeClass('hide');
                $this.find('.grid-off').removeClass('grid-off');
            });

        });

    }

    function compCounter(){
        $('.product').each(function(){
            var $this   = $(this),
                counter = $this.find('.comp-counter input'),
                plus    = $this.find('.comp-counter .plus'),
                minus   = $this.find('.comp-counter .minus');

            plus.on('click',function(){
                var val = parseInt(counter.val());
                val++;
                if (!isNaN(val)) {
                    counter.val(val);
                    $this.find('.add_to_cart_button').attr('data-quantity',val);
                }
            });

            minus.on('click',function(){
                var val = parseInt(counter.val());
                val--;
                if (val <= 0) {val = 1;}
                if (!isNaN(val)) {
                    counter.val(val);
                    $this.find('.add_to_cart_button').attr('data-quantity',val);
                }
            });
        });
    }

    function replaceSort(firstRequest){
        if (firstRequest == false) {return;}
        var sort = $('.woocommerce-ordering > .orderby').clone().removeClass('orderby').addClass('clone').attr('name','orderby_clone');
        $('.woocommerce-ordering > .orderby').remove();
        $('.woocommerce-ordering').append(sort);
    }

    function getParams() {

        var url = window.location.href;
            url = url.split('?');

        var query = url[1];
        var params = new Object;

        if (typeof(query) != 'undefined' && query != null) {
            var vars = query.split('&');
            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split('=');
                params[pair[0]] = decodeURIComponent(pair[1]);
            }
            return (jQuery.isEmptyObject(params)) ? false : params;
        }

        return false;
    }

    function updateURL(data,url){

        var shopURL = window.location.href;
            shopURL = shopURL.split('?');
            shopURL = shopURL[0];

        var firstIteration = true;

        if (typeof(url) != 'undefined' && url != null && url.length) {
            if (shopURL.indexOf("?") != -1){
                firstIteration = false
            }

            shopURL = url;

        }

        var off = ['attributes','attribute','value','action','display','post_type'];

        $.each(data, function(key, value) {

            if (typeof(value) != 'undefined' && value != null) {

                value = value.toString();
                if (value.length) {
                    if (!off.includes(key)) {
                        var symbol = '&';

                        if (firstIteration) {
                            symbol = '?';
                            firstIteration = false;
                        } else {
                            symbol = '&';
                        }

                        shopURL += symbol+key+'='+value;
                    }
                }
            }
        });

        shopURL = encodeURI(shopURL);

        if (history.pushState) {
            window.history.pushState({path:shopURL}, '', shopURL);
        }

    }

    function socialIcons(){

        var currentLink = encodeURIComponent(window.location.href);

        $('.filter-breadcrumbs .social-share').each(function(){
            var a = $(this);
            if (a.hasClass('facebook')) {
                a.attr('href','//facebook.com/sharer.php?u='+currentLink);
            } else
            if (a.hasClass('twitter')) {
                a.attr('href','//twitter.com/intent/tweet?text='+currentLink);
            } else
            if (a.hasClass('pinterest')) {
                a.attr('href','//pinterest.com/pin/create/button/?url='+currentLink);
            } else
            if (a.hasClass('linkedin')) {
                a.attr('href','//www.linkedin.com/shareArticle?mini=true&url='+currentLink);
            } else
            if (a.hasClass('whatsapp')) {
                a.attr('href','whatsapp://send?text='+currentLink);
            } else
            if (a.hasClass('viber')) {
                a.attr('href','viber://forward?text='+currentLink);
            } else
            if (a.hasClass('telegram')) {
                a.attr('href','tg://msg_url?url='+currentLink);
            }
        });
    }

    function ajaxHandler(data){

        if (request) {return;}

        request = true;

        var attrAJAX = {'action':'filter_attribues'};

        var attributes = [];

        $('.widget_product_filter_widget').first().find('.pf-item').each(function(){

            var item = $(this), atts = new Object;

            atts['name']    = item.attr('data-attribute');
            atts['label']   = item.attr('data-label');
            atts['display'] = item.attr('data-display');
            atts['columns'] = item.attr('data-columns');

            if (item.attr('data-category')) {
                atts['category'] = item.attr('data-category');
                atts['children'] = item.attr('data-children');
            }

            attributes.push(atts);

        });

        if (attributes) {
            data['attributes'] = attributes;
        }

        if (data['orderby'] === 'undefined') {
            data['orderby'] = defaultSort;
        }

        data['ajax'] = 'true';

        $.ajax({
            url:pfilter_opt.ajaxUrl,
            type: 'post',
            data: Object.assign(attrAJAX, data),
            success: function(output) {

                output = JSON.parse(output);

                var totalFound = (output['total']) ? output['total'] : 0;

                $('.woocommerce-result-count').html(output['found']);

                if ($('.woocommerce-pagination').length) {
                    $('.woocommerce-pagination ul').replaceWith(output['nav']);
                    $('#loop-products').html(output['products']);
                } else {

                    if (data['page']) {
                        $('#loop-products').append(output['products']);
                    } else {
                        $('#loop-products').html(output['products']);
                    }

                    if (output['total']) {

                        var queriedPostsNum = $('#loop-products .product').length;
                        if (queriedPostsNum == parseInt(output['total'])) {
                            $("#loadmore .text").text(noMore);
                            $("#infinite .text").text(noMore);
                            $("#loadmore").addClass('disable').removeClass('loading');
                            $("#infinite").addClass('disable').removeClass('loading');
                        } else {
                            $("#loadmore .text").text(loadMore);
                            $("#infinite .text").text(loadMore);
                            $("#infinite").removeClass('disable').removeClass('hidden');
                            $("#loadmore").removeClass('disable').removeClass('hidden');
                        }

                    } else {
                        $("#infinite").addClass('hidden');
                        $("#loadmore").addClass('hidden');
                    }

                }

                $('.product-sidebar').append('<div class="mobile-total">'+totalFound+' '+pfilter_opt.total+'</div>');

                setTimeout(function(){$('.mobile-total').remove();},1000);

                if (output['bread']) {
                    if ($('.filter-breadcrumbs').length) {
                        $('.filter-breadcrumbs').replaceWith(output['bread']);
                    } else {
                        $(output['bread']).insertBefore($('#loop-products'));
                    }

                    socialIcons();
                    
                } else {$('.filter-breadcrumbs').remove();}

                if (data['psz']) {
                    $('.product-layout')
                    .removeClass('small')
                    .removeClass('medium')
                    .removeClass('large')
                    .addClass(data['psz']);
                }
                if (data['plt']) {
                    $('.product-layout')
                    .removeClass('comp')
                    .removeClass('list')
                    .removeClass('grid')
                    .addClass(data['plt']);

                    $('.layout-control > div[data-layout="'+data['plt']+'"][data-size="'+data['psz']+'"]').addClass('chosen').siblings().removeClass('chosen');
                }

                if (output['cat_description'] && $('.term-description').length) {
                    $('.term-description').html('<p>'+output['cat_description']+'</p>');
                }

                // if (output['args']) {
                //     console.log(output['args']);
                // }
                
                compCounter();
                ajaxAddToCart();
                productCompare();
                productWishlist();
                lazyLoad(document.getElementById('loop-products'));

                replaceSort(firstRequest);
                updateURL(data,shopURLOriginal);

                showAttrOnCat();
                hideAttrOnCat();
                showAttrIfActive();


            },
            complete: function() {
                removeLoading();
                request      = false;
                firstRequest = false;
                hideClearAll();

                $("#loadmore").removeClass('loading');

            },
            error:function () {
                alert(pfilter_opt.error);
            }
        });

    }

    function eventHandler(data){

        var activeParams = getParams();

        if (
            ($('body').hasClass('tax-product_cat') && $('.pf-item.cat').length && typeof(data['ca']) == "undefined") || 
            ($('.pf-item.cat').length && typeof(data['ca']) == "undefined" && activeParams && typeof(activeParams['product_cat']) != "undefined")
        ) {
            
            if($('.pf-item.cat').hasClass('select')){
                data['ca'] = $('.pf-item.cat option:selected').val();
            } else {
                data['ca'] = $('.pf-item.cat a.chosen').data('value');
            }

            $('.pf-item.cat .clear-attribute').addClass('active');
           
        }

        if (activeParams) {

            if (typeof(activeParams['rating_filter']) != "undefined" && $('.pf-item.rating').length) {
                data['rating'] = $('.pf-item.rating a.chosen').attr('data-value');
                activeParams['rating_filter'] = '';
            }

            if (typeof(activeParams['product_cat']) != "undefined") {
                activeParams['product_cat'] = '';
            }

            var on = ['list','image','label','col'];

            if (on.includes(data['display'])) {
                $.each(activeParams, function(key, value) {
                    if (data.hasOwnProperty(key)) {
                        if (key != 'ca') {
                            var dataVal = data[key];
                            if (value.indexOf(dataVal) == -1) {
                                var valueArray = value.split(',');
                                valueArray.push(dataVal);
                                data[key] = valueArray.join(',');
                            }
                        }
                    }
                });
            }

            data = Object.assign(activeParams, data);
        }

        if(!jQuery.isEmptyObject(data)){
            ajaxHandler(data);
        };

    }

    function removeLoading(){
        $('.product-filter-overlay').removeClass('loading');
    }

    function addLoading(){
        $('.product-filter-overlay').addClass('loading');
    }

    function showClear(pfItem){
        pfItem.find('.clear-attribute').addClass('active');
    }

    function showClearAll(){
        $('.clear-all-attribute').addClass('active');
    }

    function hideClearAll(){

        var activeParams = getParams(),
            hide = false;

        if (activeParams) {

            var keys = Object.keys(activeParams);

            if ((keys.length == 1 && keys.includes('ajax')) || (keys.length == 2 && keys.includes('ajax') && keys.includes('orderby'))) {
                hide = true;
            }

        } else {
            hide = true;
        }

        if (hide) {$('.clear-all-attribute').removeClass('active');}
    }

    function hideClear(pfItem){
        pfItem.find('.clear-attribute').removeClass('active');
    }

    function showAttrOnCat(){

        var activeParams = getParams();

        if (activeParams && (activeParams['ca'] || activeParams['product_cat'])) {
            $('.cat-active').each(function(){

                if (this.hasAttribute('data-category')) {
                    var $this    = $(this);
                    var children = $this.attr('data-children');
                    var categories = $this.attr('data-category');
                    var cats       = categories.split(',');

                    if(typeof(children) != 'undefined'){
                        if (children != 'false') {
                            children = children.split(',');
                            for (var i = 0; i < children.length; i++) {
                                cats.push(children[i]);
                            }
                        }
                    }
                    
                    cats = unique(cats);

                    if (cats.includes(activeParams['ca']) || cats.includes(activeParams['product_cat'])) {
                        $this.addClass('visible');
                    } else {
                        $this.removeClass('visible');
                    }

                }

            });
        } else {
            $('.cat-active').each(function(){

                if (this.hasAttribute('data-category')) {
                    var $this    = $(this);
                    var children = $this.attr('data-children');
                    var categories = $this.attr('data-category');
                    var cats       = categories.split(',');

                    if(typeof(children) != 'undefined'){
                        if (children != 'false') {
                            children = children.split(',');
                            for (var i = 0; i < children.length; i++) {
                                cats.push(children[i]);
                            }
                        }
                    }
                    
                    cats = unique(cats);

                    var classes = [];
                    var bodyClasses = $('body').attr('class');

                    bodyClasses = bodyClasses.split(' ');

                    for (var i = 0; i < cats.length; i++) {
                        classes.push('term-'+cats[i]);
                    }

                    var has = false;

                    for (var i = 0; i < classes.length; i++) {
                        if(bodyClasses.includes(classes[i])){
                            has = true;
                        }
                    }

                    if (activeParams && typeof(activeParams['product_cat']) != 'undefined') {
                        if(classes.includes(activeParams['product_cat'])){
                            has = true;
                        }
                    }

                    if (has) {
                        $this.addClass('visible')
                    } else {
                        $this.removeClass('visible')
                    }

                }

            });
        }
        
    }

    function hideAttrOnCat(){

        var activeParams = getParams();

        if (activeParams && (activeParams['ca'] || activeParams['product_cat'])) {
            $('.cat-hide-active').each(function(){

                if (this.hasAttribute('data-category-hide')) {
                    var $this    = $(this);
                    var children = $this.attr('data-children-hide');
                    var categories = $this.attr('data-category-hide');
                    var cats       = categories.split(',');

                    if(typeof(children) != 'undefined'){
                        if (children != 'false') {
                            children = children.split(',');
                            for (var i = 0; i < children.length; i++) {
                                cats.push(children[i]);
                            }
                        }
                    }
                    
                    cats = unique(cats);

                    if (cats.includes(activeParams['ca']) || cats.includes(activeParams['product_cat'])) {
                        $this.addClass('hide');
                    } else {
                        $this.removeClass('hide');
                    }

                }

            });
        } else {
            $('.cat-hide-active').each(function(){

                if (this.hasAttribute('data-category-hide')) {
                    var $this    = $(this);
                    var children = $this.attr('data-children-hide');
                    var categories = $this.attr('data-category-hide');
                    var cats       = categories.split(',');

                    if(typeof(children) != 'undefined'){
                        if (children != 'false') {
                            children = children.split(',');
                            for (var i = 0; i < children.length; i++) {
                                cats.push(children[i]);
                            }
                        }
                    }
                    
                    cats = unique(cats);

                    var classes = [];
                    var bodyClasses = $('body').attr('class');

                    bodyClasses = bodyClasses.split(' ');

                    for (var i = 0; i < cats.length; i++) {
                        classes.push('term-'+cats[i]);
                    }

                    var has = false;

                    for (var i = 0; i < classes.length; i++) {
                        if(bodyClasses.includes(classes[i])){
                            has = true;
                        }
                    }

                    if (activeParams && typeof(activeParams['product_cat']) != 'undefined') {
                        if(classes.includes(activeParams['product_cat'])){
                            has = true;
                        }
                    }

                    if (has) {
                        $this.addClass('hide')
                    } else {
                        $this.removeClass('hide')
                    }

                }

            });
        }
        
    }

    function showAttrIfActive(){

        var activeParams = getParams();

        if (activeParams && $('.pf-item.attr').length){

            $('.pf-item.attr').each(function(){
                var attr = $(this);
                if (typeof(activeParams['filter_'+attr.data('attribute')]) != 'undefined') {
                    attr.addClass('visible');
                }
            });

        }
    }

    function pfItemPrice(slider){

        var max       = slider.find('.slider').data('max'),
            min       = slider.find('.slider').data('min'),
            step      = slider.find('.slider').data('step'),
            currency  = slider.find('.slider').data('currency'),
            position  = slider.find('.slider').data('position'),
            handle    = slider.find( ".ui-slider-handle" ),
            values    = slider.data('values');

            if (typeof(values) != 'undefined' && values != null && values.length) {
                values = values.split(',');
            } else {
                values = [ min, max ]
            }

        var data = new Object,
            attribute = slider.attr('data-attribute'),
            display = slider.attr('data-display');

        data['attribute'] = attribute;
        data['display'] = display;

        var sliderRange = slider.find('.slider').slider({
            range:true,
            max: max,
            min: min,
            step: step,
            values: values,
            create: function( event, ui ) {

                var price1 = currency+values[0],
                    price2 = currency+values[1];

                if (position == 'right') {
                    price1 = values[0]+currency;
                    price2 = values[1]+currency;
                }

                handle.eq(0).find('.ui-slider-handle-bubble').text( price1 );
                handle.eq(1).find('.ui-slider-handle-bubble').text( price2 );

                slider.find('input[name="min"]').val(values[0]);
                slider.find('input[name="max"]').val(values[1]);

            },
            slide: function( event, ui ) {

                var price = currency+ui.value;

                if (position == 'right') {
                    price = ui.value+currency;
                }

                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( price );

                slider.find('input[name="min"]').val(ui.values[0]);
                slider.find('input[name="max"]').val(ui.values[1]);

            },
            change: function( event, ui ) {

                var price = currency+ui.value;

                if (position == 'right') {
                    price = ui.value+currency;
                }

                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( price );

                slider.find('input[name="min"]').val(ui.values[0]);
                slider.find('input[name="max"]').val(ui.values[1]);

            },
            stop: function( event, ui ) {

                var price = currency+ui.value;

                if (position == 'right') {
                    price = ui.value+currency;
                }

                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( price );

                slider.find('input[name="min"]').val(ui.values[0]);
                slider.find('input[name="max"]').val(ui.values[1]);

                addLoading();

                data['page'] = '';
                data['min_price'] = ui.values[0];
                data['max_price'] = ui.values[1];

                eventHandler(data);

                showClear(slider);
                showClearAll();
            }
        });

        slider.find('input[name="min"]').on( "change", function() {
            if (!isNaN($(this).val())) {
                var  values = [parseInt($(this).val()), parseInt(slider.find('input[name="max"]').val())];
                sliderRange.slider( "values", values );

                addLoading();

                data['page'] = '';
                data['min_price'] = values[0];
                data['max_price'] = values[1];

                eventHandler(data);

                showClear(slider);
                showClearAll();
            }
        });

        slider.find('input[name="max"]').on( "change", function() {
            if (!isNaN($(this).val())) {
                var  values = [parseInt(slider.find('input[name="min"]').val()),parseInt($(this).val())];
                sliderRange.slider( "values", values );

                addLoading();

                data['page'] = '';
                data['min_price'] = values[0];
                data['max_price'] = values[1];

                eventHandler(data);

                showClear(slider);
                showClearAll();
            }
        });

    }

    function pfItemSlider(slider){

        var max       = slider.find('.slider').data('max'),
            min       = slider.find('.slider').data('min'),
            handle    = slider.find( ".ui-slider-handle" ),
            values    = slider.data('values');

            if (typeof(values) != 'undefined') {
                values = values.split(',');
            } else {
                values = [ min, max ];
            }

        var data = new Object,
            attribute = slider.attr('data-attribute'),
            display = slider.attr('data-display');

        data['attribute'] = attribute;
        data['display']   = display;

        var sliderRange = slider.find('.slider').slider({
            range:true,
            max: max,
            min: min,
            values: values,
            create: function( event, ui ) {
                handle.eq(0).find('.ui-slider-handle-bubble').text( values[0] );
                handle.eq(1).find('.ui-slider-handle-bubble').text( values[1] );

                slider.find('input[name="min"]').val(values[0]);
                slider.find('input[name="max"]').val(values[1]);
            },
            slide: function( event, ui ) {
                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( ui.value );

                slider.find('input[name="min"]').val(ui.values[0]);
                slider.find('input[name="max"]').val(ui.values[1]);
            },
            change: function( event, ui ) {

                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( ui.value );

            },
            stop: function( event, ui ) {

                handle.eq(ui.handleIndex).find('.ui-slider-handle-bubble').text( ui.value );

                addLoading();

                data['filter_'+attribute] = '';
                data['page'] = '';
                data[attribute+'_min_value'] = ui.values[0];
                data[attribute+'_max_value'] = ui.values[1];

                slider.find('input[name="min"]').val(ui.values[0]);
                slider.find('input[name="max"]').val(ui.values[1]);

                eventHandler(data);

                showClear(slider);
                showClearAll();

            }
        });

        slider.find('input[name="min"]').on( "change", function() {
            if (!isNaN($(this).val())) {
                var  values = [parseInt($(this).val()), parseInt(slider.find('input[name="max"]').val())];
                sliderRange.slider( "values", values );

                addLoading();

                data['filter_'+attribute] = '';
                data['page'] = '';
                data[attribute+'_min_value'] = values[0];
                data[attribute+'_max_value'] = values[1];

                slider.find('input[name="min"]').val(values[0]);
                slider.find('input[name="max"]').val(values[1]);

                eventHandler(data);

                showClear(slider);
                showClearAll();
            }
        });

        slider.find('input[name="max"]').on( "change", function() {
            if (!isNaN($(this).val())) {
                var  values = [parseInt(slider.find('input[name="min"]').val()),parseInt($(this).val())];
                sliderRange.slider( "values", values );

                addLoading();

                data['filter_'+attribute] = '';
                data['page'] = '';
                data[attribute+'_min_value'] = values[0];
                data[attribute+'_max_value'] = values[1];

                slider.find('input[name="min"]').val(values[0]);
                slider.find('input[name="max"]').val(values[1]);

                eventHandler(data);

                showClear(slider);
                showClearAll();
            }
        });
    }

    function pfItemSliderRebuild(pfItem){

        pfItem.find('.slider').slider("destroy");

        var max       = pfItem.find('.slider').data('max'),
            min       = pfItem.find('.slider').data('min');

        pfItem.removeData('values');
        pfItem.find('.slider').append('<div class="ui-slider-handle"><span class="ui-slider-handle-bubble min">'+min+'</span></div><div class="ui-slider-handle"><span class="ui-slider-handle-bubble max">'+max+'</span></div>')

        pfItemSlider(pfItem);
    }

    function pfItemPriceRebuild(pfItem){
        pfItem.find('.slider').slider("destroy");
                    
        var max       = pfItem.find('.slider').data('max'),
            min       = pfItem.find('.slider').data('min'),
            currency  = pfItem.find('.slider').data('currency'),
            position  = pfItem.find('.slider').data('position');

        if (position == 'right') {
            max = max+currency;
            min = min+currency;
        } else {
            max = currency+max;
            min = currency+min;
        }

        pfItem.removeData('values');
        pfItem.find('.slider').append('<div class="ui-slider-handle"><span class="ui-slider-handle-bubble min">'+min+'</span></div><div class="ui-slider-handle"><span class="ui-slider-handle-bubble max">'+max+'</span></div>')

        pfItemPrice(pfItem);
    }

    function clearAttributes(pfItem){
        pfItem.find('.clear-attribute').on('click',function(){

            addLoading();

            var clear = $(this);
            clear.removeClass('active');

            if (pfItem.hasClass('slider')) {

                pfItemSliderRebuild(pfItem);

                var data      = new Object,
                    attribute = pfItem.attr('data-attribute'),
                    display   = pfItem.attr('data-display');

                data['page'] = '';
                data['filter_'+attribute] = '';
                data['pn'] = '';
                data[attribute+'_min_value'] = '';
                data[attribute+'_max_value'] = '';
                eventHandler(data);

            } else
            if (pfItem.hasClass('price')) {

                pfItemPriceRebuild(pfItem);

                var data      = new Object,
                    attribute = pfItem.attr('data-attribute'),
                    display   = pfItem.attr('data-display');

                data['page'] = '';
                data['min_price'] = '';
                data['max_price'] = '';
                eventHandler(data);

            } else
            if (pfItem.hasClass('clickable')) {

                display   = pfItem.attr('data-display');

                pfItem.find('a').each(function(){
                    $(this).removeClass('chosen');
                });

                pfItem.find('.hidden').removeClass('hidden');
                pfItem.find('.isolate').removeClass('isolate');
                pfItem.find('.hide').removeClass('hide');
                pfItem.find('.disable').removeClass('disable');
                pfItem.find('.grid-off').removeClass('grid-off');

                if (pfItem.hasClass('cat') && display == 'list') {
                    pfItem.find('.toggle.active').trigger('click');
                }

                pfItem.find('.active').removeClass('active');

                var data      = new Object,
                    attribute = pfItem.attr('data-attribute'),
                    display   = pfItem.attr('data-display');

                data['page'] = '';
                data['filter_'+attribute] = '';
                data['attribute'] = attribute;
                data['display'] = display;
                data['value'] = '';
                data['rating_filter'] = '';
                data['product_cat'] = '';
                data[attribute] = data['value'];

                eventHandler(data);

            } else
            if (pfItem.hasClass('select')) {
                pfItem.find('select').val('');

                var data      = new Object,
                    attribute = pfItem.attr('data-attribute'),
                    display   = pfItem.attr('data-display');

                data['page'] = '';
                data['filter_'+attribute] = '';
                data['attribute'] = attribute;
                data['display'] = display;
                data['value'] = '';
                data[attribute] = data['value'];

                eventHandler(data);
            }

        });
    }

    function clearAll(widget){
        $("body").on('click','.clear-all-attribute',function(e){

            e.preventDefault()

            addLoading();

            var clear = $(this);
            clear.removeClass('active');


            widget.find('.pf-item').each(function(){

                var pfItem = $(this);

                pfItem.find('.clear-attribute').removeClass('active');
                pfItem.find('.hidden').removeClass('hidden');
                pfItem.find('.isolate').removeClass('isolate');
                pfItem.find('.hide').removeClass('hide');
                pfItem.find('.disable').removeClass('disable');
                pfItem.find('.grid-off').removeClass('grid-off');

                if (pfItem.hasClass('cat') && pfItem.data('display') == 'list') {
                    pfItem.find('.toggle.active').trigger('click');
                }

                pfItem.find('.active').removeClass('active');

                if (pfItem.hasClass('slider')) {
                    pfItemSliderRebuild(pfItem);
                } else
                if (pfItem.hasClass('price')) {
                    pfItemPriceRebuild(pfItem);
                } else
                if (pfItem.hasClass('clickable')) {
                    pfItem.find('a').each(function(){
                        $(this).removeClass('chosen');
                    });
                } else
                if (pfItem.hasClass('select')) {
                    pfItem.find('select').val('');
                }
            });

            var activeParams = getParams();

            if (activeParams) {
                $.each(activeParams, function(key, value) {
                    if (key != 'data_shop') {activeParams[key]='';}
                });
                eventHandler(activeParams);
            }

            $('.woocommerce-ordering select option[value="'+defaultSort+'"]').attr('selected','selected').siblings().removeAttr('selected');

            $('.product-layout')
            .removeClass('comp')
            .removeClass('list')
            .removeClass('grid')
            .removeClass('small')
            .removeClass('medium')
            .removeClass('large')
            .addClass(defaultLayout)
            .addClass(defaultSize);

            $('.sale-products').removeClass('chosen');

            if (defaultLayout == "grid") {
                switch(defaultSize){
                    case 'small':
                    $('.layout-control div[data-layout="grid"][data-size="small"]').addClass('chosen').siblings().removeClass('chosen');
                    break;
                    case 'medium':
                    $('.layout-control div[data-layout="grid"][data-size="medium"]').addClass('chosen').siblings().removeClass('chosen');
                    break;
                    case 'large':
                    $('.layout-control div[data-layout="grid"][data-size="large"]').addClass('chosen').siblings().removeClass('chosen');
                    break;
                }
            } else if(defaultLayout == "comp") {
                $('.layout-control div[data-layout="comp"]').addClass('chosen').siblings().removeClass('chosen');

            } else {
                $('.layout-control div').addClass('chosen').removeClass('chosen');
            }

        });
    }

    function widget(){

        var widget = $('.widget_product_filter_widget').first();
        var activeParams = getParams();

         if (activeParams && activeParams['ajax'] == 'true') {
            var nav = $('#loop-products').data('nav');

            if (nav != 'pagination') {
                activeParams['page'] = '';
            }

            addLoading();
            ajaxHandler(activeParams);

            $('.clear-all-attribute').addClass('active');
        }


        widget.find('.pf-item.slider').each(function(){

            var $this = $(this);

            if (activeParams && activeParams['ajax'] == 'true') {

                var name = $this.attr('data-attribute');

                if (typeof(activeParams[name+'_max_value']) != 'undefined') {

                    var values = [activeParams[name+'_min_value'],activeParams[name+'_max_value']];

                    $this.data( "values",values.join(','));

                    $this.find('.clear-attribute').addClass('active');
                }
            }

            pfItemSlider($this);
            clearAttributes($this);

        });

        widget.find('.pf-item.price').each(function(){

            var $this = $(this);

            if (activeParams) {
                if (typeof(activeParams['max_price']) != 'undefined') {

                    var values = [activeParams['min_price'],activeParams['max_price']];

                    $this.data( "values",values.join(','));

                    $this.find('.clear-attribute').addClass('active');
                }
            }

            pfItemPrice($this);
            clearAttributes($this);

        });

        widget.find('.pf-item.clickable').each(function(){

            var data      = new Object,
                item      = $(this),
                attribute = item.attr('data-attribute'),
                display = item.attr('data-display'),
                exists  = false;

            data['page']      = '';
            data['attribute'] = attribute;
            data['display']   = display;

            if (activeParams) {

                if (typeof(activeParams[attribute]) != 'undefined' && activeParams['ajax'] == 'true') {

                    var activeAtts = activeParams[attribute];

                    activeAtts = activeAtts.split(',');

                    for (var i = 0; i < activeAtts.length; i++) {
                        item.find('a[data-value="'+activeAtts[i]+'"]').addClass('chosen');
                    }

                    if (item.hasClass('rating') && item.find('a.chosen').length) {
                        item.find('a.chosen').parent().siblings().addClass('hidden');
                    }

                    if (item.hasClass('cat') && item.find('a.chosen').length) {
                        if (display == 'list') {
                            item.find('a.chosen').parents('ul:not(".category")').prev('a').find('.toggle').trigger('click');
                        } else if(display == 'image') {

                            var a = item.find('a.chosen');
                            a.parents('ul').prev('a').trigger('click');
                            a.trigger('click');

                        }
                    }

                    item.find('.clear-attribute').addClass('active');
                    
                }

                if (typeof(activeParams['filter_'+attribute]) != 'undefined') {
                    exists = true;
                }

                if (exists) {
                    item.find('.clear-attribute').addClass('active');
                }
            }

            item.find('a').on('click',function(e){

                var a = $(this);

                if (item.hasClass('cat')) {
                    a.addClass('chosen');
                    item.find('.chosen').not(a).removeClass('chosen');
                } else {
                    a.toggleClass('chosen');

                    if (item.hasClass('rating')) {
                        a.parent().siblings().addClass('hidden');
                    }

                }

                e.preventDefault();

                addLoading();

                if (a.hasClass('chosen')) {
                    if (exists) {

                        if (a.parents('ul').find('.chosen').length) {

                            var values = [];

                            a.parents('ul').find('.chosen').each(function(){
                                values.push($(this).attr('data-value'));
                            });

                            if (values.length) {
                                data['value'] = values.join(',');
                                data['filter_'+attribute] = '';
                                showClear(item);
                                showClearAll();
                            }
                            
                        } else {
                            hideClear(item);
                            data['value'] = '';
                        }
                    } else {
                        data['value'] = a.attr('data-value');
                        showClear(item);
                        showClearAll();
                    }
                    
                } else {

                    if (a.parents('ul').find('.chosen').length) {

                        var values = [];

                        a.parents('ul').find('.chosen').each(function(){
                            values.push($(this).attr('data-value'));
                        });

                        if (values.length) {
                            data['value'] = values.join(',');
                        }
                        
                    } else {
                        hideClear(item);
                        data['value'] = '';
                        data['filter_'+attribute] = '';
                    }
                    
                }

                data[attribute] = data['value'];

                eventHandler(data);

            });

            clearAttributes(item);

        });

        widget.find('.pf-item.select').each(function(){

            var data      = new Object,
                item      = $(this),
                attribute = item.attr('data-attribute'),
                display = item.attr('data-display'),
                exists  = false;

            data['page']      = '';
            data['attribute'] = attribute;
            data['display'] = display;

            if (activeParams) {

                if (typeof(activeParams[attribute]) != 'undefined' || typeof(activeParams['filter_'+attribute]) != 'undefined') {
                    item.find('option[value="'+ activeParams[attribute]+'"]').attr('selected','selected');
                    
                }

                if (typeof(activeParams['filter_'+attribute]) != 'undefined') {
                    exists = true;
                }

                if (exists) {
                    item.find('.clear-attribute').addClass('active');
                }

            }

            item.find('select').on('change',function(){

                addLoading();

                var thisVal = $(this).val();

                if (thisVal.length) {
                    showClear(item);
                    showClearAll();
                } else {
                    hideClear(item);
                }

                data['value'] = thisVal;

                data[attribute] = data['value'];

                eventHandler(data);

            });

            clearAttributes(item);

        });

    }

    scrollbar();
    catLayout();
    widget();
    clearAll($('.widget_product_filter_widget').first());
    showAttrOnCat();
    hideAttrOnCat();
    showAttrIfActive();

    $("body").on('change','.woocommerce-ordering > .clone',function(){
        var activeParams = getParams();
        if (activeParams['ajax'] == "true") {
            activeParams['orderby'] = $(this).val();

            var nav = $('#loop-products').data('nav');

            if (nav != 'pagination' && activeParams['page']) {
                activeParams['page'] = '';
            }

            addLoading();
            eventHandler(activeParams);
        }
    });

    $(".layout-control div").on('click',function(){

        var $this  = $(this),
            size   = $this.attr('data-size'),
            layout = $this.attr('data-layout'),
            data   = new Object;

        $this.addClass('chosen').siblings().removeClass('chosen');

        var activeParams = getParams();

        if (activeParams) {
            if (activeParams['ajax'] == "true") {
                var nav = $('#loop-products').data('nav');
                if (nav != 'pagination' && activeParams['page']) {
                    activeParams['page'] ='';
                }
            }
            data = activeParams;
        }

        data['plt'] = layout;
        data['psz'] = size;


        addLoading();
        eventHandler(data);

    });

    $('.sale-products').on('click',function(){

        var $this  = $(this),
            data   = new Object;

        $this.toggleClass('chosen');


        var activeParams = getParams();

        if (activeParams) {
            data = activeParams;
        }

        data['onsale'] = ($this.hasClass('chosen')) ? 1 : '';

        addLoading();
        eventHandler(data);



    });

    $("body").on('click','.page-numbers.ajax a',function(e){
        e.preventDefault();
        var activeParams = getParams();
        if (activeParams['ajax'] == "true") {

            var link = $(this);
            var current = (typeof(activeParams['page']) != 'undefined' && activeParams['page'] != null) ? parseInt(activeParams['page']) : 1;

            activeParams['page'] = (link.hasClass('next')) ? current + 1 : (link.hasClass('prev')) ? current - 1 : link.data('page');

            addLoading();
            ajaxHandler(activeParams);

        }
    });

    $("body").on('click','.filter-breadcrumbs .share > a',function(e){
        e.preventDefault();
        $(this).parent().toggleClass('show');
    });
    
    if ($("#loadmore").length) {

        $("#loadmore").on('click',function(e){
            e.preventDefault();
            var activeParams = getParams();
            if (activeParams) {
                if (activeParams['ajax'] == "true") {

                    $(this).addClass('loading');

                    var current = (typeof(activeParams['page']) != 'undefined' && activeParams['page'] != null) ? parseInt(activeParams['page']) : 1;

                    activeParams['page'] = current + 1;

                    ajaxHandler(activeParams);

                }
            }
        });

    }

    if ($("#infinite").length) {

        var infinite = $("#infinite");

        $(window).scroll(function(){

            if (!infinite.hasClass('disable') && !infinite.hasClass('hidden')) {

                var activeParams = getParams();

                if (activeParams) {
                    if (activeParams['ajax'] == "true") {
                        if  (infinite.inView()){
                            infinite.addClass('loading');

                            var current = (typeof(activeParams['page']) != 'undefined' && activeParams['page'] != null) ? parseInt(activeParams['page']) : 1;

                            activeParams['page'] = current + 1;

                            ajaxHandler(activeParams);
                        }
                    }
                }

            }
        });

    }

    var activeParams = getParams();

    if (activeParams) {
        var activeCategory = activeParams['product_cat'];

        if (typeof(activeParams['rating_filter']) != "undefined" && $('.pf-item.rating').length) {
            var chosen = $('.pf-item.rating a[data-value="'+activeParams['rating_filter']+'"]').addClass('chosen');
            chosen.parent().siblings().addClass('hidden');
            $('.pf-item.rating .clear-attribute').addClass('active');
        }


        var activeLayout = activeParams['plt'],
            activeSize   = activeParams['psz'],
            onSale       = activeParams['onsale'];

        if (typeof(activeLayout) != "undefined" && typeof(activeSize) != "undefined") {
            $('.product-layout')
            .removeClass('comp')
            .removeClass('list')
            .removeClass('grid')
            .removeClass('small')
            .removeClass('medium')
            .removeClass('large')
            .addClass(activeLayout)
            .addClass(activeSize);

            $('.layout-control > div[data-layout="'+defaultLayout+'"][data-size="'+defaultSort+'"]').addClass('chosen').siblings().removeClass('chosen');

        }

        if (activeLayout == "grid") {
            switch(activeSize){
                case 'small':
                $('.layout-control div[data-layout="grid"][data-size="small"]').addClass('chosen').siblings().removeClass('chosen');
                break;
                case 'medium':
                $('.layout-control div[data-layout="grid"][data-size="medium"]').addClass('chosen').siblings().removeClass('chosen');
                break;
                case 'large':
                $('.layout-control div[data-layout="grid"][data-size="large"]').addClass('chosen').siblings().removeClass('chosen');
                break;
            }
        } else if(activeLayout == "list") {
            $('.layout-control div[data-layout="list"]').addClass('chosen').siblings().removeClass('chosen');

        } else {
            $('.layout-control > div[data-layout="'+defaultLayout+'"][data-size="'+defaultSort+'"]').addClass('chosen').siblings().removeClass('chosen');
        }

        if (typeof(onSale) != "undefined") {
            $('.sale-products').addClass('chosen');
        }


    }

    if ($('.pf-item.list.cat').length) {
        $('.pf-item.list.cat a').each(function(){
            if ($('body').hasClass('term-'+$(this).data('value')) || (typeof(activeCategory) != 'undefined') && activeCategory == $(this).data('value')) {
                $(this).addClass('chosen');
                $(this).parents('ul').prev('a').find('.toggle').trigger('click');
            }
        });
    }

    if ($('.pf-item.image.cat').length) {
        $('.pf-item.image[data-attribute="ca"]').each(function(){

            var $this = $(this);

            $this.find('a').each(function(){

                var a = $(this);

                if ($('body').hasClass('term-'+a.data('value')) || (typeof(activeCategory) != 'undefined') && activeCategory == $(this).data('value')) {

                    a.parents('li').addClass('isolate').siblings().addClass('hide');
                    $this.find('.isolate').not(a.parent()).addClass('disable');
                    a.parents('ul').addClass('grid-off');

                    if (a.next('ul').length != 0) {
                        a.trigger('click');
                    } else {
                        a.parent().addClass('active').removeClass('isolate');
                        a.parent().siblings().removeClass('hide');
                        a.parent().parent().removeClass('grid-off');
                        a.parent().parent().parent().removeClass('disable');
                    }

                }
            });

        });
    }

    if ($('.pf-item.select.cat').length) {
        $('.pf-item.select[data-attribute="ca"]').each(function(){

            var $this = $(this);

            $this.find('select option').each(function(){

                var option = $(this);

                if ($('body').hasClass('term-'+option.data('value')) || (typeof(activeCategory) != 'undefined') && activeCategory == $(this).val()) {
                    option.attr('selected','selected').siblings().removeAttr('selected');
                }
            });

        });
    }

    if ($('.pf-item.attr').length) {

        $('.pf-item.attr').each(function(){
            var attr = $(this);

            if(attr.hasClass('clickable')){
                attr.find('a').each(function(){
                    if ($('body').hasClass('term-'+$(this).data('value')) || (typeof(activeParams['filter_'+attr.data('attribute')]) != 'undefined') && activeParams['filter_'+attr.data('attribute')] == $(this).data('value')) {
                        $(this).addClass('chosen');
                    }
                });
            } else if (attr.hasClass('select')){
                attr.find('option').each(function(){
                    if ($('body').hasClass('term-'+$(this).val()) || (typeof(activeParams['filter_'+attr.data('attribute')]) != 'undefined') && activeParams['filter_'+attr.data('attribute')] == $(this).val()) {
                        $(this).attr('selected','selected');
                    }
                });
            }
        });
        
    }

    if ($('.pf-item.cat').length) {
        if (((($('.pf-item.cat').hasClass('image') && $('.pf-item.cat li.active').length) || ($('.pf-item.cat').hasClass('list')) && $('.pf-item.cat a.chosen').length)) || ($('.pf-item.cat').hasClass('select') && $('.pf-item.cat option:selected').val())) {
            $('.pf-item.cat').find('.clear-attribute').addClass('active');
        }
    }

    $('.filter-breadcrumbs').addClass('cs');

})(jQuery);